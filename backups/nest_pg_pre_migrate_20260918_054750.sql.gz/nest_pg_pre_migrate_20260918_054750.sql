--
-- PostgreSQL database dump
--

\restrict oJuLe0hBXFutax0qOBwtHL4682x0mIDSHuIrDfDz0e9xOPexlSq3Y6FftVEwmzn

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AccountStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."AccountStatus" AS ENUM (
    'active',
    'suspended',
    'deleted'
);


ALTER TYPE public."AccountStatus" OWNER TO chataura_user;

--
-- Name: AgencyAffiliationStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."AgencyAffiliationStatus" AS ENUM (
    'pending',
    'accepted',
    'rejected',
    'left'
);


ALTER TYPE public."AgencyAffiliationStatus" OWNER TO chataura_user;

--
-- Name: AgencyWeeklyStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."AgencyWeeklyStatus" AS ENUM (
    'pending',
    'approved',
    'rejected',
    'paid'
);


ALTER TYPE public."AgencyWeeklyStatus" OWNER TO chataura_user;

--
-- Name: FollowStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."FollowStatus" AS ENUM (
    'accepted',
    'pending'
);


ALTER TYPE public."FollowStatus" OWNER TO chataura_user;

--
-- Name: FriendRequestStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."FriendRequestStatus" AS ENUM (
    'pending',
    'accepted',
    'rejected',
    'cancelled'
);


ALTER TYPE public."FriendRequestStatus" OWNER TO chataura_user;

--
-- Name: GameBetStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."GameBetStatus" AS ENUM (
    'placed',
    'won',
    'lost'
);


ALTER TYPE public."GameBetStatus" OWNER TO chataura_user;

--
-- Name: GameRoundPhase; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."GameRoundPhase" AS ENUM (
    'betting',
    'drawing',
    'completed'
);


ALTER TYPE public."GameRoundPhase" OWNER TO chataura_user;

--
-- Name: MediaKind; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."MediaKind" AS ENUM (
    'post',
    'reel'
);


ALTER TYPE public."MediaKind" OWNER TO chataura_user;

--
-- Name: PaymentSource; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."PaymentSource" AS ENUM (
    'RAZORPAY',
    'EARNINGS_WALLET',
    'MOCK'
);


ALTER TYPE public."PaymentSource" OWNER TO chataura_user;

--
-- Name: PurchaseStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."PurchaseStatus" AS ENUM (
    'pending',
    'success',
    'failed'
);


ALTER TYPE public."PurchaseStatus" OWNER TO chataura_user;

--
-- Name: RoomMemberRole; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."RoomMemberRole" AS ENUM (
    'host',
    'co_host',
    'speaker',
    'listener'
);


ALTER TYPE public."RoomMemberRole" OWNER TO chataura_user;

--
-- Name: StarChatStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."StarChatStatus" AS ENUM (
    'active',
    'ended'
);


ALTER TYPE public."StarChatStatus" OWNER TO chataura_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'user',
    'seller',
    'admin',
    'agency'
);


ALTER TYPE public."UserRole" OWNER TO chataura_user;

--
-- Name: WithdrawalStatus; Type: TYPE; Schema: public; Owner: chataura_user
--

CREATE TYPE public."WithdrawalStatus" AS ENUM (
    'pending',
    'approved',
    'rejected',
    'completed',
    'cancelled'
);


ALTER TYPE public."WithdrawalStatus" OWNER TO chataura_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO chataura_user;

--
-- Name: admin_settings; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.admin_settings (
    id integer DEFAULT 1 NOT NULL,
    gems_per_coin numeric(12,4) DEFAULT 10 NOT NULL,
    min_gems_convert_to_coins integer DEFAULT 10 NOT NULL,
    coin_to_xp_ratio numeric(12,4) DEFAULT 0.1 NOT NULL,
    gift_commission_pct numeric(8,2) DEFAULT 20 NOT NULL,
    earnings_purchase_enabled boolean DEFAULT true NOT NULL,
    cashout_enabled boolean DEFAULT false NOT NULL,
    audio_call_price_per_min integer DEFAULT 20 NOT NULL,
    video_call_price_per_min integer DEFAULT 40 NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    star_chat_commission_pct numeric(8,2) DEFAULT 30 NOT NULL,
    star_chat_heartbeat_seconds integer DEFAULT 25 NOT NULL,
    star_chat_price_per_min integer DEFAULT 5 NOT NULL,
    spin_cost integer DEFAULT 50 NOT NULL,
    bonus_config jsonb
);


ALTER TABLE public.admin_settings OWNER TO chataura_user;

--
-- Name: agency_affiliations; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.agency_affiliations (
    id bigint NOT NULL,
    agency_user_id bigint NOT NULL,
    room_owner_id bigint NOT NULL,
    room_id uuid,
    status public."AgencyAffiliationStatus" DEFAULT 'pending'::public."AgencyAffiliationStatus" NOT NULL,
    joined_at timestamp(6) with time zone,
    left_at timestamp(6) with time zone,
    cooldown_until timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.agency_affiliations OWNER TO chataura_user;

--
-- Name: agency_affiliations_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.agency_affiliations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agency_affiliations_id_seq OWNER TO chataura_user;

--
-- Name: agency_affiliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.agency_affiliations_id_seq OWNED BY public.agency_affiliations.id;


--
-- Name: agency_weekly_distributions; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.agency_weekly_distributions (
    id bigint NOT NULL,
    period_id bigint NOT NULL,
    week_start date NOT NULL,
    week_end date NOT NULL,
    agency_user_id bigint NOT NULL,
    room_owner_id bigint NOT NULL,
    suggested_gems integer DEFAULT 0 NOT NULL,
    approved_gems integer,
    status public."AgencyWeeklyStatus" DEFAULT 'pending'::public."AgencyWeeklyStatus" NOT NULL,
    notes text,
    paid_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.agency_weekly_distributions OWNER TO chataura_user;

--
-- Name: agency_weekly_distributions_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.agency_weekly_distributions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agency_weekly_distributions_id_seq OWNER TO chataura_user;

--
-- Name: agency_weekly_distributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.agency_weekly_distributions_id_seq OWNED BY public.agency_weekly_distributions.id;


--
-- Name: banners; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.banners (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    subtitle character varying(255),
    category character varying(32) DEFAULT 'event'::character varying NOT NULL,
    badge_text character varying(64),
    image_url text,
    bg_color_start character varying(16),
    bg_color_end character varying(16),
    button_text character varying(64),
    action_type character varying(32),
    action_target text,
    details_content text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.banners OWNER TO chataura_user;

--
-- Name: banners_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.banners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.banners_id_seq OWNER TO chataura_user;

--
-- Name: banners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.banners_id_seq OWNED BY public.banners.id;


--
-- Name: blocked_users; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.blocked_users (
    id bigint NOT NULL,
    blocker_id bigint NOT NULL,
    blocked_id bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.blocked_users OWNER TO chataura_user;

--
-- Name: blocked_users_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.blocked_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blocked_users_id_seq OWNER TO chataura_user;

--
-- Name: blocked_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.blocked_users_id_seq OWNED BY public.blocked_users.id;


--
-- Name: bonus_claims; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.bonus_claims (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind character varying(32) NOT NULL,
    coins integer DEFAULT 0 NOT NULL,
    meta jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.bonus_claims OWNER TO chataura_user;

--
-- Name: bonus_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.bonus_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bonus_claims_id_seq OWNER TO chataura_user;

--
-- Name: bonus_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.bonus_claims_id_seq OWNED BY public.bonus_claims.id;


--
-- Name: coin_packages; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.coin_packages (
    id bigint NOT NULL,
    audience character varying(32) DEFAULT 'user'::character varying NOT NULL,
    coins integer NOT NULL,
    currency character varying(8) DEFAULT 'INR'::character varying NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    base_price_inr numeric(12,2),
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.coin_packages OWNER TO chataura_user;

--
-- Name: coin_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.coin_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coin_packages_id_seq OWNER TO chataura_user;

--
-- Name: coin_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.coin_packages_id_seq OWNED BY public.coin_packages.id;


--
-- Name: coin_purchase_transactions; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.coin_purchase_transactions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    package_id bigint,
    razorpay_order_id character varying(64),
    razorpay_payment_id character varying(64),
    razorpay_signature character varying(255),
    amount_minor integer NOT NULL,
    currency character varying(8) NOT NULL,
    coins_credited integer NOT NULL,
    status public."PurchaseStatus" DEFAULT 'pending'::public."PurchaseStatus" NOT NULL,
    payment_source public."PaymentSource" DEFAULT 'RAZORPAY'::public."PaymentSource" NOT NULL,
    country character varying(8),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.coin_purchase_transactions OWNER TO chataura_user;

--
-- Name: coin_purchase_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.coin_purchase_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coin_purchase_transactions_id_seq OWNER TO chataura_user;

--
-- Name: coin_purchase_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.coin_purchase_transactions_id_seq OWNED BY public.coin_purchase_transactions.id;


--
-- Name: coin_transactions; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.coin_transactions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(64) NOT NULL,
    title character varying(255),
    coin_amount bigint NOT NULL,
    net_amount bigint,
    commission_amount bigint,
    balance_after bigint,
    reference_id character varying(128),
    status character varying(32) DEFAULT 'success'::character varying NOT NULL,
    meta jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.coin_transactions OWNER TO chataura_user;

--
-- Name: coin_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.coin_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coin_transactions_id_seq OWNER TO chataura_user;

--
-- Name: coin_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.coin_transactions_id_seq OWNED BY public.coin_transactions.id;


--
-- Name: conversation_participants; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.conversation_participants (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    user_id bigint NOT NULL,
    last_read_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversation_participants OWNER TO chataura_user;

--
-- Name: conversation_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.conversation_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversation_participants_id_seq OWNER TO chataura_user;

--
-- Name: conversation_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.conversation_participants_id_seq OWNED BY public.conversation_participants.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.conversations (
    id bigint NOT NULL,
    type character varying(16) DEFAULT 'private'::character varying NOT NULL,
    name character varying(255),
    image_url text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.conversations OWNER TO chataura_user;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.conversations_id_seq OWNER TO chataura_user;

--
-- Name: conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.conversations_id_seq OWNED BY public.conversations.id;


--
-- Name: entry_bars; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.entry_bars (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    level_required integer DEFAULT 1 NOT NULL,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.entry_bars OWNER TO chataura_user;

--
-- Name: entry_bars_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.entry_bars_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.entry_bars_id_seq OWNER TO chataura_user;

--
-- Name: entry_bars_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.entry_bars_id_seq OWNED BY public.entry_bars.id;


--
-- Name: faq_items; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.faq_items (
    id bigint NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.faq_items OWNER TO chataura_user;

--
-- Name: faq_items_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.faq_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faq_items_id_seq OWNER TO chataura_user;

--
-- Name: faq_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.faq_items_id_seq OWNED BY public.faq_items.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.feedback (
    id bigint NOT NULL,
    user_id bigint,
    message text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.feedback OWNER TO chataura_user;

--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedback_id_seq OWNER TO chataura_user;

--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.feedback_id_seq OWNED BY public.feedback.id;


--
-- Name: frames; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.frames (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    slug character varying(128),
    category character varying(64),
    level_required integer DEFAULT 1 NOT NULL,
    coin_cost integer,
    is_premium boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    image_url text,
    animation_key character varying(128),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.frames OWNER TO chataura_user;

--
-- Name: frames_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.frames_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.frames_id_seq OWNER TO chataura_user;

--
-- Name: frames_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.frames_id_seq OWNED BY public.frames.id;


--
-- Name: friend_requests; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.friend_requests (
    id bigint NOT NULL,
    sender_id bigint NOT NULL,
    receiver_id bigint NOT NULL,
    status public."FriendRequestStatus" DEFAULT 'pending'::public."FriendRequestStatus" NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.friend_requests OWNER TO chataura_user;

--
-- Name: friend_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.friend_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.friend_requests_id_seq OWNER TO chataura_user;

--
-- Name: friend_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.friend_requests_id_seq OWNED BY public.friend_requests.id;


--
-- Name: friendships; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.friendships (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    friend_id bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.friendships OWNER TO chataura_user;

--
-- Name: friendships_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.friendships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.friendships_id_seq OWNER TO chataura_user;

--
-- Name: friendships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.friendships_id_seq OWNED BY public.friendships.id;


--
-- Name: gem_conversions; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.gem_conversions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    gems_debited bigint NOT NULL,
    currency character varying(16) NOT NULL,
    coins_credited bigint DEFAULT 0 NOT NULL,
    gems_balance_after bigint NOT NULL,
    wallet_balance_after bigint,
    gems_per_coin numeric(12,4) NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.gem_conversions OWNER TO chataura_user;

--
-- Name: gem_conversions_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.gem_conversions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gem_conversions_id_seq OWNER TO chataura_user;

--
-- Name: gem_conversions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.gem_conversions_id_seq OWNED BY public.gem_conversions.id;


--
-- Name: gifts; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.gifts (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    coin_cost integer NOT NULL,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    animation_url text
);


ALTER TABLE public.gifts OWNER TO chataura_user;

--
-- Name: gifts_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.gifts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gifts_id_seq OWNER TO chataura_user;

--
-- Name: gifts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.gifts_id_seq OWNED BY public.gifts.id;


--
-- Name: greedy_bets; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.greedy_bets (
    id bigint NOT NULL,
    round_id bigint NOT NULL,
    user_id bigint NOT NULL,
    item character varying(32) NOT NULL,
    chip_amount bigint NOT NULL,
    multiplier integer NOT NULL,
    potential_payout bigint NOT NULL,
    actual_payout bigint DEFAULT 0 NOT NULL,
    status public."GameBetStatus" DEFAULT 'placed'::public."GameBetStatus" NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.greedy_bets OWNER TO chataura_user;

--
-- Name: greedy_bets_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.greedy_bets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.greedy_bets_id_seq OWNER TO chataura_user;

--
-- Name: greedy_bets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.greedy_bets_id_seq OWNED BY public.greedy_bets.id;


--
-- Name: greedy_rounds; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.greedy_rounds (
    id bigint NOT NULL,
    phase public."GameRoundPhase" DEFAULT 'betting'::public."GameRoundPhase" NOT NULL,
    betting_ends_at timestamp(6) with time zone NOT NULL,
    winning_item character varying(32),
    winning_multiplier integer,
    settled_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.greedy_rounds OWNER TO chataura_user;

--
-- Name: greedy_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.greedy_rounds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.greedy_rounds_id_seq OWNER TO chataura_user;

--
-- Name: greedy_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.greedy_rounds_id_seq OWNED BY public.greedy_rounds.id;


--
-- Name: levels; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.levels (
    id integer NOT NULL,
    level integer NOT NULL,
    min_xp integer NOT NULL,
    max_xp integer NOT NULL,
    label character varying(64),
    badge_url text,
    icon_url text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.levels OWNER TO chataura_user;

--
-- Name: levels_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.levels_id_seq OWNER TO chataura_user;

--
-- Name: levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.levels_id_seq OWNED BY public.levels.id;


--
-- Name: lucky77_bets; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.lucky77_bets (
    id bigint NOT NULL,
    round_id bigint NOT NULL,
    user_id bigint NOT NULL,
    option character varying(32) NOT NULL,
    chip_amount bigint NOT NULL,
    multiplier integer NOT NULL,
    potential_payout bigint NOT NULL,
    actual_payout bigint DEFAULT 0 NOT NULL,
    status public."GameBetStatus" DEFAULT 'placed'::public."GameBetStatus" NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lucky77_bets OWNER TO chataura_user;

--
-- Name: lucky77_bets_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.lucky77_bets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lucky77_bets_id_seq OWNER TO chataura_user;

--
-- Name: lucky77_bets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.lucky77_bets_id_seq OWNED BY public.lucky77_bets.id;


--
-- Name: lucky77_rounds; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.lucky77_rounds (
    id bigint NOT NULL,
    phase public."GameRoundPhase" DEFAULT 'betting'::public."GameRoundPhase" NOT NULL,
    betting_ends_at timestamp(6) with time zone NOT NULL,
    winning_item character varying(32),
    winning_multiplier integer,
    settled_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lucky77_rounds OWNER TO chataura_user;

--
-- Name: lucky77_rounds_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.lucky77_rounds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lucky77_rounds_id_seq OWNER TO chataura_user;

--
-- Name: lucky77_rounds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.lucky77_rounds_id_seq OWNED BY public.lucky77_rounds.id;


--
-- Name: media_comments; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.media_comments (
    id bigint NOT NULL,
    media_id bigint NOT NULL,
    user_id bigint NOT NULL,
    comment text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_comments OWNER TO chataura_user;

--
-- Name: media_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.media_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_comments_id_seq OWNER TO chataura_user;

--
-- Name: media_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.media_comments_id_seq OWNED BY public.media_comments.id;


--
-- Name: media_items; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.media_items (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kind public."MediaKind" NOT NULL,
    media_type character varying(16) NOT NULL,
    file_url text NOT NULL,
    thumbnail_url text,
    caption text,
    music_url text,
    effect_name character varying(128),
    duration integer,
    aspect_ratio character varying(16),
    is_camera_recorded boolean DEFAULT false NOT NULL,
    likes_count integer DEFAULT 0 NOT NULL,
    comments_count integer DEFAULT 0 NOT NULL,
    shares_count integer DEFAULT 0 NOT NULL,
    views_count integer DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_items OWNER TO chataura_user;

--
-- Name: media_items_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.media_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_items_id_seq OWNER TO chataura_user;

--
-- Name: media_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.media_items_id_seq OWNED BY public.media_items.id;


--
-- Name: media_likes; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.media_likes (
    id bigint NOT NULL,
    media_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_likes OWNER TO chataura_user;

--
-- Name: media_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.media_likes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_likes_id_seq OWNER TO chataura_user;

--
-- Name: media_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.media_likes_id_seq OWNED BY public.media_likes.id;


--
-- Name: media_saves; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.media_saves (
    id bigint NOT NULL,
    media_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.media_saves OWNER TO chataura_user;

--
-- Name: media_saves_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.media_saves_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_saves_id_seq OWNER TO chataura_user;

--
-- Name: media_saves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.media_saves_id_seq OWNED BY public.media_saves.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    sender_id bigint NOT NULL,
    message_type character varying(32) DEFAULT 'text'::character varying NOT NULL,
    message_text text,
    message_media text,
    gift_id bigint,
    sticker_id bigint,
    status character varying(16) DEFAULT 'sent'::character varying NOT NULL,
    client_uuid character varying(64),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO chataura_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO chataura_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: music_tracks; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.music_tracks (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    artist character varying(255),
    file_url text NOT NULL,
    is_trending boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.music_tracks OWNER TO chataura_user;

--
-- Name: music_tracks_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.music_tracks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.music_tracks_id_seq OWNER TO chataura_user;

--
-- Name: music_tracks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.music_tracks_id_seq OWNED BY public.music_tracks.id;


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id bigint NOT NULL,
    token character varying(64) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO chataura_user;

--
-- Name: room_blocks; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.room_blocks (
    id bigint NOT NULL,
    room_id uuid NOT NULL,
    user_id bigint NOT NULL,
    reason character varying(255),
    kind character varying(16) DEFAULT 'block'::character varying NOT NULL,
    expires_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.room_blocks OWNER TO chataura_user;

--
-- Name: room_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.room_blocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_blocks_id_seq OWNER TO chataura_user;

--
-- Name: room_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.room_blocks_id_seq OWNED BY public.room_blocks.id;


--
-- Name: room_members; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.room_members (
    id bigint NOT NULL,
    room_id uuid NOT NULL,
    user_id bigint NOT NULL,
    role public."RoomMemberRole" DEFAULT 'listener'::public."RoomMemberRole" NOT NULL,
    seat_index integer,
    agora_uid integer,
    is_active boolean DEFAULT true NOT NULL,
    last_heartbeat_at timestamp(6) with time zone,
    joined_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.room_members OWNER TO chataura_user;

--
-- Name: room_members_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.room_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_members_id_seq OWNER TO chataura_user;

--
-- Name: room_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.room_members_id_seq OWNED BY public.room_members.id;


--
-- Name: room_themes; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.room_themes (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    image_url text,
    coin_cost integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.room_themes OWNER TO chataura_user;

--
-- Name: room_themes_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.room_themes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_themes_id_seq OWNER TO chataura_user;

--
-- Name: room_themes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.room_themes_id_seq OWNED BY public.room_themes.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.rooms (
    id uuid NOT NULL,
    display_id character varying(8) NOT NULL,
    title character varying(255) NOT NULL,
    owner_id bigint NOT NULL,
    host_id bigint,
    co_host_id bigint,
    agora_channel_name character varying(128) NOT NULL,
    max_seats integer DEFAULT 8 NOT NULL,
    is_live boolean DEFAULT true NOT NULL,
    is_permanent boolean DEFAULT false NOT NULL,
    cover_image_url text,
    description text,
    tags jsonb,
    settings jsonb,
    theme_id bigint,
    country_code character varying(8),
    allowed_country character varying(8),
    allowed_gender character varying(16),
    min_age integer,
    max_age integer,
    last_activity_at timestamp(6) with time zone,
    host_last_heartbeat_at timestamp(6) with time zone,
    ended_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.rooms OWNER TO chataura_user;

--
-- Name: seats; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.seats (
    id bigint NOT NULL,
    room_id uuid NOT NULL,
    seat_index integer NOT NULL,
    user_id bigint,
    is_muted boolean DEFAULT false NOT NULL,
    muted_by_user_id bigint,
    is_locked boolean DEFAULT false NOT NULL,
    last_heartbeat_at timestamp(6) with time zone
);


ALTER TABLE public.seats OWNER TO chataura_user;

--
-- Name: seats_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.seats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.seats_id_seq OWNER TO chataura_user;

--
-- Name: seats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.seats_id_seq OWNED BY public.seats.id;


--
-- Name: star_chat_sessions; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.star_chat_sessions (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    payer_id bigint NOT NULL,
    star_user_id bigint NOT NULL,
    status public."StarChatStatus" DEFAULT 'active'::public."StarChatStatus" NOT NULL,
    started_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ended_at timestamp(6) with time zone,
    payer_heartbeat_at timestamp(6) with time zone,
    price_per_min integer NOT NULL,
    commission_percent numeric(8,2) NOT NULL,
    coins_charged bigint DEFAULT 0 NOT NULL,
    gems_credited bigint DEFAULT 0 NOT NULL,
    end_reason character varying(64)
);


ALTER TABLE public.star_chat_sessions OWNER TO chataura_user;

--
-- Name: star_chat_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.star_chat_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.star_chat_sessions_id_seq OWNER TO chataura_user;

--
-- Name: star_chat_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.star_chat_sessions_id_seq OWNED BY public.star_chat_sessions.id;


--
-- Name: stickers; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.stickers (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    coin_cost integer DEFAULT 0 NOT NULL,
    image_url text,
    animation_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.stickers OWNER TO chataura_user;

--
-- Name: stickers_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.stickers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stickers_id_seq OWNER TO chataura_user;

--
-- Name: stickers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.stickers_id_seq OWNED BY public.stickers.id;


--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.user_devices (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    device_id character varying(255),
    platform character varying(32),
    fcm_token text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.user_devices OWNER TO chataura_user;

--
-- Name: user_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.user_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_devices_id_seq OWNER TO chataura_user;

--
-- Name: user_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.user_devices_id_seq OWNED BY public.user_devices.id;


--
-- Name: user_followers; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.user_followers (
    id bigint NOT NULL,
    follower_id bigint NOT NULL,
    following_id bigint NOT NULL,
    status public."FollowStatus" DEFAULT 'accepted'::public."FollowStatus" NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_followers OWNER TO chataura_user;

--
-- Name: user_followers_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.user_followers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_followers_id_seq OWNER TO chataura_user;

--
-- Name: user_followers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.user_followers_id_seq OWNED BY public.user_followers.id;


--
-- Name: user_reports; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.user_reports (
    id bigint NOT NULL,
    reporter_id bigint NOT NULL,
    reported_id bigint NOT NULL,
    reason character varying(64) NOT NULL,
    description text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_reports OWNER TO chataura_user;

--
-- Name: user_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.user_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_reports_id_seq OWNER TO chataura_user;

--
-- Name: user_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.user_reports_id_seq OWNED BY public.user_reports.id;


--
-- Name: user_unlocked_frames; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.user_unlocked_frames (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    frame_id bigint NOT NULL,
    coins_paid integer DEFAULT 0 NOT NULL,
    unlocked_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone
);


ALTER TABLE public.user_unlocked_frames OWNER TO chataura_user;

--
-- Name: user_unlocked_frames_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.user_unlocked_frames_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_unlocked_frames_id_seq OWNER TO chataura_user;

--
-- Name: user_unlocked_frames_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.user_unlocked_frames_id_seq OWNED BY public.user_unlocked_frames.id;


--
-- Name: user_unlocked_stickers; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.user_unlocked_stickers (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    sticker_id bigint NOT NULL,
    coins_paid integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_unlocked_stickers OWNER TO chataura_user;

--
-- Name: user_unlocked_stickers_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.user_unlocked_stickers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_unlocked_stickers_id_seq OWNER TO chataura_user;

--
-- Name: user_unlocked_stickers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.user_unlocked_stickers_id_seq OWNED BY public.user_unlocked_stickers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(255),
    phone character varying(32),
    password character varying(255) NOT NULL,
    name character varying(255),
    display_name character varying(255),
    avatar_url text,
    bio text,
    gender character varying(16),
    dob date,
    language character varying(16),
    country character varying(8),
    role public."UserRole" DEFAULT 'user'::public."UserRole" NOT NULL,
    invite_code character varying(16),
    invited_by bigint,
    email_verified_at timestamp(6) with time zone,
    fcm_token text,
    level integer DEFAULT 1 NOT NULL,
    exp integer DEFAULT 0 NOT NULL,
    xp integer DEFAULT 0 NOT NULL,
    coin_balance bigint DEFAULT 0 NOT NULL,
    wallet_balance bigint DEFAULT 0 NOT NULL,
    referral_balance bigint DEFAULT 0 NOT NULL,
    gems bigint DEFAULT 0 NOT NULL,
    inr_earnings_balance bigint DEFAULT 0 NOT NULL,
    usd_earnings_balance bigint DEFAULT 0 NOT NULL,
    private_account boolean DEFAULT false NOT NULL,
    is_private boolean DEFAULT false NOT NULL,
    show_online_status boolean DEFAULT true NOT NULL,
    is_online boolean DEFAULT false NOT NULL,
    last_seen_at timestamp(6) with time zone,
    is_suspended boolean DEFAULT false NOT NULL,
    suspended_reason text,
    suspended_until timestamp(6) with time zone,
    account_status public."AccountStatus" DEFAULT 'active'::public."AccountStatus" NOT NULL,
    deleted_at timestamp(6) with time zone,
    is_star_account boolean DEFAULT false NOT NULL,
    star_rank integer,
    star_bio_tag character varying(255),
    audio_call_rate integer,
    video_call_rate integer,
    selected_frame_id bigint,
    last_client_country character varying(8),
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    selected_entry_bar_id bigint,
    total_earned_coins bigint DEFAULT 0 NOT NULL,
    streak_count integer DEFAULT 0 NOT NULL,
    last_streak_at timestamp(6) with time zone
);


ALTER TABLE public.users OWNER TO chataura_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO chataura_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: withdrawal_requests; Type: TABLE; Schema: public; Owner: chataura_user
--

CREATE TABLE public.withdrawal_requests (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character varying(8) NOT NULL,
    withdrawal_source character varying(32) NOT NULL,
    status public."WithdrawalStatus" DEFAULT 'pending'::public."WithdrawalStatus" NOT NULL,
    note text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


ALTER TABLE public.withdrawal_requests OWNER TO chataura_user;

--
-- Name: withdrawal_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: chataura_user
--

CREATE SEQUENCE public.withdrawal_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.withdrawal_requests_id_seq OWNER TO chataura_user;

--
-- Name: withdrawal_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: chataura_user
--

ALTER SEQUENCE public.withdrawal_requests_id_seq OWNED BY public.withdrawal_requests.id;


--
-- Name: agency_affiliations id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_affiliations ALTER COLUMN id SET DEFAULT nextval('public.agency_affiliations_id_seq'::regclass);


--
-- Name: agency_weekly_distributions id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_weekly_distributions ALTER COLUMN id SET DEFAULT nextval('public.agency_weekly_distributions_id_seq'::regclass);


--
-- Name: banners id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.banners ALTER COLUMN id SET DEFAULT nextval('public.banners_id_seq'::regclass);


--
-- Name: blocked_users id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.blocked_users ALTER COLUMN id SET DEFAULT nextval('public.blocked_users_id_seq'::regclass);


--
-- Name: bonus_claims id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.bonus_claims ALTER COLUMN id SET DEFAULT nextval('public.bonus_claims_id_seq'::regclass);


--
-- Name: coin_packages id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_packages ALTER COLUMN id SET DEFAULT nextval('public.coin_packages_id_seq'::regclass);


--
-- Name: coin_purchase_transactions id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_purchase_transactions ALTER COLUMN id SET DEFAULT nextval('public.coin_purchase_transactions_id_seq'::regclass);


--
-- Name: coin_transactions id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_transactions ALTER COLUMN id SET DEFAULT nextval('public.coin_transactions_id_seq'::regclass);


--
-- Name: conversation_participants id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.conversation_participants ALTER COLUMN id SET DEFAULT nextval('public.conversation_participants_id_seq'::regclass);


--
-- Name: conversations id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.conversations ALTER COLUMN id SET DEFAULT nextval('public.conversations_id_seq'::regclass);


--
-- Name: entry_bars id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.entry_bars ALTER COLUMN id SET DEFAULT nextval('public.entry_bars_id_seq'::regclass);


--
-- Name: faq_items id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.faq_items ALTER COLUMN id SET DEFAULT nextval('public.faq_items_id_seq'::regclass);


--
-- Name: feedback id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.feedback ALTER COLUMN id SET DEFAULT nextval('public.feedback_id_seq'::regclass);


--
-- Name: frames id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.frames ALTER COLUMN id SET DEFAULT nextval('public.frames_id_seq'::regclass);


--
-- Name: friend_requests id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friend_requests ALTER COLUMN id SET DEFAULT nextval('public.friend_requests_id_seq'::regclass);


--
-- Name: friendships id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friendships ALTER COLUMN id SET DEFAULT nextval('public.friendships_id_seq'::regclass);


--
-- Name: gem_conversions id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.gem_conversions ALTER COLUMN id SET DEFAULT nextval('public.gem_conversions_id_seq'::regclass);


--
-- Name: gifts id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.gifts ALTER COLUMN id SET DEFAULT nextval('public.gifts_id_seq'::regclass);


--
-- Name: greedy_bets id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.greedy_bets ALTER COLUMN id SET DEFAULT nextval('public.greedy_bets_id_seq'::regclass);


--
-- Name: greedy_rounds id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.greedy_rounds ALTER COLUMN id SET DEFAULT nextval('public.greedy_rounds_id_seq'::regclass);


--
-- Name: levels id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.levels ALTER COLUMN id SET DEFAULT nextval('public.levels_id_seq'::regclass);


--
-- Name: lucky77_bets id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.lucky77_bets ALTER COLUMN id SET DEFAULT nextval('public.lucky77_bets_id_seq'::regclass);


--
-- Name: lucky77_rounds id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.lucky77_rounds ALTER COLUMN id SET DEFAULT nextval('public.lucky77_rounds_id_seq'::regclass);


--
-- Name: media_comments id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_comments ALTER COLUMN id SET DEFAULT nextval('public.media_comments_id_seq'::regclass);


--
-- Name: media_items id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_items ALTER COLUMN id SET DEFAULT nextval('public.media_items_id_seq'::regclass);


--
-- Name: media_likes id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_likes ALTER COLUMN id SET DEFAULT nextval('public.media_likes_id_seq'::regclass);


--
-- Name: media_saves id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_saves ALTER COLUMN id SET DEFAULT nextval('public.media_saves_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: music_tracks id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.music_tracks ALTER COLUMN id SET DEFAULT nextval('public.music_tracks_id_seq'::regclass);


--
-- Name: room_blocks id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_blocks ALTER COLUMN id SET DEFAULT nextval('public.room_blocks_id_seq'::regclass);


--
-- Name: room_members id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_members ALTER COLUMN id SET DEFAULT nextval('public.room_members_id_seq'::regclass);


--
-- Name: room_themes id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_themes ALTER COLUMN id SET DEFAULT nextval('public.room_themes_id_seq'::regclass);


--
-- Name: seats id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.seats ALTER COLUMN id SET DEFAULT nextval('public.seats_id_seq'::regclass);


--
-- Name: star_chat_sessions id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.star_chat_sessions ALTER COLUMN id SET DEFAULT nextval('public.star_chat_sessions_id_seq'::regclass);


--
-- Name: stickers id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.stickers ALTER COLUMN id SET DEFAULT nextval('public.stickers_id_seq'::regclass);


--
-- Name: user_devices id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_devices ALTER COLUMN id SET DEFAULT nextval('public.user_devices_id_seq'::regclass);


--
-- Name: user_followers id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_followers ALTER COLUMN id SET DEFAULT nextval('public.user_followers_id_seq'::regclass);


--
-- Name: user_reports id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_reports ALTER COLUMN id SET DEFAULT nextval('public.user_reports_id_seq'::regclass);


--
-- Name: user_unlocked_frames id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_frames ALTER COLUMN id SET DEFAULT nextval('public.user_unlocked_frames_id_seq'::regclass);


--
-- Name: user_unlocked_stickers id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_stickers ALTER COLUMN id SET DEFAULT nextval('public.user_unlocked_stickers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: withdrawal_requests id; Type: DEFAULT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.withdrawal_requests ALTER COLUMN id SET DEFAULT nextval('public.withdrawal_requests_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
f4672eb2-b9a8-4714-be6c-129910218a94	3c7e25a6af2e206813cf7ba530aa1d78b5aa2794e0408dc1effed3f07b9f001a	2026-09-18 05:28:04.130885+00	20260911174411_phase2_auth_user	\N	\N	2026-09-18 05:28:04.03398+00	1
8eb75a5e-f684-4996-bbbe-4c02a5bb14e5	c4dbb182c57cb064b46bcc963d8fa8ba63831733de22ef7b6d1f67e2af872029	2026-09-18 05:28:04.259668+00	20260911175622_phase3_wallet_gamification	\N	\N	2026-09-18 05:28:04.13195+00	1
48563416-7bf7-4616-bff9-868cb3caf2e0	b9cd3da69378ad37e4c8136e300f34b0885c35243962dca3fca82ec43cc6d32b	2026-09-18 05:28:04.388735+00	20260912163000_phase4_rooms_games_chat	\N	\N	2026-09-18 05:28:04.260734+00	1
b269f6f4-0024-4422-982c-d66966240731	cd5f160cc84b9c4880435e6fbe376216f8016aa08a8fd279aa2932c3193fb4d3	2026-09-18 05:28:04.481175+00	20260913100000_phase5_media_agency_admin	\N	\N	2026-09-18 05:28:04.389667+00	1
cc540b9a-af02-49d0-b436-3be558153ea0	6853542c00cbd418be83e678d38c1be622b43dcd3c5ae98909e2be3db5f2b9b7	2026-09-18 05:28:04.500062+00	20260913200000_phase6_spin_bonus	\N	\N	2026-09-18 05:28:04.482096+00	1
\.


--
-- Data for Name: admin_settings; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.admin_settings (id, gems_per_coin, min_gems_convert_to_coins, coin_to_xp_ratio, gift_commission_pct, earnings_purchase_enabled, cashout_enabled, audio_call_price_per_min, video_call_price_per_min, updated_at, star_chat_commission_pct, star_chat_heartbeat_seconds, star_chat_price_per_min, spin_cost, bonus_config) FROM stdin;
1	10.0000	10	0.1000	20.00	t	f	20	40	2026-09-18 05:28:57.944+00	30.00	25	5	50	\N
\.


--
-- Data for Name: agency_affiliations; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.agency_affiliations (id, agency_user_id, room_owner_id, room_id, status, joined_at, left_at, cooldown_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agency_weekly_distributions; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.agency_weekly_distributions (id, period_id, week_start, week_end, agency_user_id, room_owner_id, suggested_gems, approved_gems, status, notes, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: banners; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.banners (id, title, subtitle, category, badge_text, image_url, bg_color_start, bg_color_end, button_text, action_type, action_target, details_content, sort_order, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blocked_users; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.blocked_users (id, blocker_id, blocked_id, created_at) FROM stdin;
\.


--
-- Data for Name: bonus_claims; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.bonus_claims (id, user_id, kind, coins, meta, created_at) FROM stdin;
\.


--
-- Data for Name: coin_packages; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.coin_packages (id, audience, coins, currency, price, original_price, base_price_inr, is_active, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coin_purchase_transactions; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.coin_purchase_transactions (id, user_id, package_id, razorpay_order_id, razorpay_payment_id, razorpay_signature, amount_minor, currency, coins_credited, status, payment_source, country, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coin_transactions; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.coin_transactions (id, user_id, type, title, coin_amount, net_amount, commission_amount, balance_after, reference_id, status, meta, created_at) FROM stdin;
\.


--
-- Data for Name: conversation_participants; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.conversation_participants (id, conversation_id, user_id, last_read_at, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.conversations (id, type, name, image_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: entry_bars; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.entry_bars (id, name, level_required, image_url, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: faq_items; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.faq_items (id, question, answer, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.feedback (id, user_id, message, created_at) FROM stdin;
\.


--
-- Data for Name: frames; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.frames (id, name, slug, category, level_required, coin_cost, is_premium, is_active, image_url, animation_key, created_at) FROM stdin;
\.


--
-- Data for Name: friend_requests; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.friend_requests (id, sender_id, receiver_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: friendships; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.friendships (id, user_id, friend_id, created_at) FROM stdin;
\.


--
-- Data for Name: gem_conversions; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.gem_conversions (id, user_id, gems_debited, currency, coins_credited, gems_balance_after, wallet_balance_after, gems_per_coin, created_at) FROM stdin;
\.


--
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.gifts (id, name, coin_cost, image_url, is_active, created_at, animation_url) FROM stdin;
\.


--
-- Data for Name: greedy_bets; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.greedy_bets (id, round_id, user_id, item, chip_amount, multiplier, potential_payout, actual_payout, status, created_at) FROM stdin;
\.


--
-- Data for Name: greedy_rounds; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.greedy_rounds (id, phase, betting_ends_at, winning_item, winning_multiplier, settled_at, created_at) FROM stdin;
1	completed	2026-09-18 05:28:24.829+00	carrot	5	2026-09-18 05:28:24.845+00	2026-09-18 05:28:04.829+00
2	completed	2026-09-18 05:28:44.851+00	chilli	5	2026-09-18 05:28:44.865+00	2026-09-18 05:28:24.852+00
3	completed	2026-09-18 05:29:04.869+00	chilli	5	2026-09-18 05:29:04.884+00	2026-09-18 05:28:44.869+00
4	completed	2026-09-18 05:29:24.891+00	chilli	5	2026-09-18 05:29:24.901+00	2026-09-18 05:29:04.894+00
5	completed	2026-09-18 05:29:44.906+00	corn	5	2026-09-18 05:29:44.92+00	2026-09-18 05:29:24.907+00
6	completed	2026-09-18 05:30:04.924+00	chilli	5	2026-09-18 05:30:04.968+00	2026-09-18 05:29:44.924+00
7	completed	2026-09-18 05:30:24.987+00	chilli	5	2026-09-18 05:30:25.979+00	2026-09-18 05:30:04.987+00
8	completed	2026-09-18 05:30:45.986+00	chilli	5	2026-09-18 05:30:46.01+00	2026-09-18 05:30:25.987+00
9	completed	2026-09-18 05:31:06.014+00	chilli	5	2026-09-18 05:31:06.042+00	2026-09-18 05:30:46.014+00
10	completed	2026-09-18 05:31:26.048+00	fish	10	2026-09-18 05:31:26.066+00	2026-09-18 05:31:06.049+00
11	completed	2026-09-18 05:31:46.077+00	cow	25	2026-09-18 05:31:46.097+00	2026-09-18 05:31:26.078+00
12	completed	2026-09-18 05:32:06.101+00	tomato	5	2026-09-18 05:32:06.119+00	2026-09-18 05:31:46.101+00
13	completed	2026-09-18 05:32:26.123+00	tomato	5	2026-09-18 05:32:26.144+00	2026-09-18 05:32:06.123+00
14	completed	2026-09-18 05:32:46.147+00	tomato	5	2026-09-18 05:32:46.175+00	2026-09-18 05:32:26.148+00
15	completed	2026-09-18 05:33:06.181+00	corn	5	2026-09-18 05:33:06.203+00	2026-09-18 05:32:46.183+00
16	completed	2026-09-18 05:33:26.208+00	crab	15	2026-09-18 05:33:26.229+00	2026-09-18 05:33:06.208+00
17	completed	2026-09-18 05:33:46.234+00	carrot	5	2026-09-18 05:33:46.254+00	2026-09-18 05:33:26.234+00
18	completed	2026-09-18 05:34:06.258+00	carrot	5	2026-09-18 05:34:06.283+00	2026-09-18 05:33:46.259+00
19	completed	2026-09-18 05:34:26.286+00	chilli	5	2026-09-18 05:34:26.31+00	2026-09-18 05:34:06.287+00
20	completed	2026-09-18 05:34:46.316+00	tomato	5	2026-09-18 05:34:46.331+00	2026-09-18 05:34:26.317+00
21	completed	2026-09-18 05:35:06.334+00	tomato	5	2026-09-18 05:35:06.358+00	2026-09-18 05:34:46.335+00
22	completed	2026-09-18 05:35:26.363+00	cow	25	2026-09-18 05:35:26.376+00	2026-09-18 05:35:06.364+00
23	completed	2026-09-18 05:35:46.384+00	carrot	5	2026-09-18 05:35:46.396+00	2026-09-18 05:35:26.384+00
24	completed	2026-09-18 05:36:06.401+00	cow	25	2026-09-18 05:36:06.414+00	2026-09-18 05:35:46.402+00
25	completed	2026-09-18 05:36:26.42+00	tomato	5	2026-09-18 05:36:26.436+00	2026-09-18 05:36:06.421+00
26	completed	2026-09-18 05:36:46.44+00	tomato	5	2026-09-18 05:36:46.454+00	2026-09-18 05:36:26.441+00
27	completed	2026-09-18 05:37:06.458+00	carrot	5	2026-09-18 05:37:06.479+00	2026-09-18 05:36:46.459+00
28	completed	2026-09-18 05:37:26.485+00	carrot	5	2026-09-18 05:37:26.503+00	2026-09-18 05:37:06.485+00
29	completed	2026-09-18 05:37:46.507+00	chilli	5	2026-09-18 05:37:46.537+00	2026-09-18 05:37:26.507+00
30	completed	2026-09-18 05:38:06.54+00	corn	5	2026-09-18 05:38:06.562+00	2026-09-18 05:37:46.541+00
31	completed	2026-09-18 05:38:26.566+00	tomato	5	2026-09-18 05:38:26.587+00	2026-09-18 05:38:06.567+00
32	completed	2026-09-18 05:38:46.592+00	tomato	5	2026-09-18 05:38:46.617+00	2026-09-18 05:38:26.593+00
33	completed	2026-09-18 05:39:06.622+00	tomato	5	2026-09-18 05:39:06.647+00	2026-09-18 05:38:46.623+00
34	completed	2026-09-18 05:39:26.651+00	carrot	5	2026-09-18 05:39:26.664+00	2026-09-18 05:39:06.652+00
35	completed	2026-09-18 05:39:46.667+00	corn	5	2026-09-18 05:39:46.683+00	2026-09-18 05:39:26.668+00
36	completed	2026-09-18 05:40:06.687+00	cow	25	2026-09-18 05:40:06.706+00	2026-09-18 05:39:46.688+00
37	completed	2026-09-18 05:40:26.711+00	carrot	5	2026-09-18 05:40:26.726+00	2026-09-18 05:40:06.712+00
38	completed	2026-09-18 05:40:46.736+00	corn	5	2026-09-18 05:40:46.753+00	2026-09-18 05:40:26.737+00
39	completed	2026-09-18 05:41:06.758+00	tomato	5	2026-09-18 05:41:06.777+00	2026-09-18 05:40:46.759+00
40	completed	2026-09-18 05:41:26.787+00	carrot	5	2026-09-18 05:41:26.802+00	2026-09-18 05:41:06.788+00
41	completed	2026-09-18 05:41:46.806+00	corn	5	2026-09-18 05:41:46.818+00	2026-09-18 05:41:26.806+00
42	completed	2026-09-18 05:42:06.821+00	chilli	5	2026-09-18 05:42:06.843+00	2026-09-18 05:41:46.821+00
43	completed	2026-09-18 05:42:26.851+00	tomato	5	2026-09-18 05:42:26.859+00	2026-09-18 05:42:06.851+00
44	completed	2026-09-18 05:42:46.863+00	chilli	5	2026-09-18 05:42:46.876+00	2026-09-18 05:42:26.863+00
45	completed	2026-09-18 05:43:06.88+00	fish	10	2026-09-18 05:43:06.895+00	2026-09-18 05:42:46.88+00
46	completed	2026-09-18 05:43:26.899+00	corn	5	2026-09-18 05:43:26.919+00	2026-09-18 05:43:06.899+00
47	completed	2026-09-18 05:43:46.923+00	carrot	5	2026-09-18 05:43:46.952+00	2026-09-18 05:43:26.924+00
48	completed	2026-09-18 05:44:06.956+00	corn	5	2026-09-18 05:44:06.975+00	2026-09-18 05:43:46.957+00
49	completed	2026-09-18 05:44:26.978+00	tomato	5	2026-09-18 05:44:27.001+00	2026-09-18 05:44:06.979+00
50	completed	2026-09-18 05:44:47.006+00	tomato	5	2026-09-18 05:44:47.037+00	2026-09-18 05:44:27.007+00
51	completed	2026-09-18 05:45:07.041+00	chilli	5	2026-09-18 05:45:07.072+00	2026-09-18 05:44:47.041+00
52	completed	2026-09-18 05:45:27.076+00	chilli	5	2026-09-18 05:45:27.094+00	2026-09-18 05:45:07.077+00
53	completed	2026-09-18 05:45:47.1+00	fish	10	2026-09-18 05:45:47.131+00	2026-09-18 05:45:27.1+00
54	completed	2026-09-18 05:46:07.14+00	carrot	5	2026-09-18 05:46:07.159+00	2026-09-18 05:45:47.141+00
55	completed	2026-09-18 05:46:27.162+00	corn	5	2026-09-18 05:46:27.178+00	2026-09-18 05:46:07.163+00
56	completed	2026-09-18 05:46:47.182+00	crab	15	2026-09-18 05:46:47.202+00	2026-09-18 05:46:27.182+00
57	completed	2026-09-18 05:47:07.205+00	chilli	5	2026-09-18 05:47:07.232+00	2026-09-18 05:46:47.206+00
58	completed	2026-09-18 05:47:27.237+00	fish	10	2026-09-18 05:47:27.258+00	2026-09-18 05:47:07.238+00
59	completed	2026-09-18 05:47:47.262+00	tomato	5	2026-09-18 05:47:47.285+00	2026-09-18 05:47:27.263+00
60	betting	2026-09-18 05:48:07.288+00	\N	\N	\N	2026-09-18 05:47:47.288+00
\.


--
-- Data for Name: levels; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.levels (id, level, min_xp, max_xp, label, badge_url, icon_url, created_at) FROM stdin;
\.


--
-- Data for Name: lucky77_bets; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.lucky77_bets (id, round_id, user_id, option, chip_amount, multiplier, potential_payout, actual_payout, status, created_at) FROM stdin;
\.


--
-- Data for Name: lucky77_rounds; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.lucky77_rounds (id, phase, betting_ends_at, winning_item, winning_multiplier, settled_at, created_at) FROM stdin;
1	completed	2026-09-18 05:28:24.834+00	watermelon	2	2026-09-18 05:28:24.854+00	2026-09-18 05:28:04.835+00
2	completed	2026-09-18 05:28:44.86+00	plum	2	2026-09-18 05:28:44.871+00	2026-09-18 05:28:24.86+00
3	completed	2026-09-18 05:29:04.876+00	watermelon	2	2026-09-18 05:29:04.896+00	2026-09-18 05:28:44.877+00
4	completed	2026-09-18 05:29:24.902+00	watermelon	2	2026-09-18 05:29:24.909+00	2026-09-18 05:29:04.903+00
5	completed	2026-09-18 05:29:44.914+00	watermelon	2	2026-09-18 05:29:44.926+00	2026-09-18 05:29:24.914+00
6	completed	2026-09-18 05:30:04.929+00	watermelon	2	2026-09-18 05:30:04.994+00	2026-09-18 05:29:44.93+00
7	completed	2026-09-18 05:30:25.012+00	watermelon	2	2026-09-18 05:30:25.99+00	2026-09-18 05:30:05.013+00
8	completed	2026-09-18 05:30:45.996+00	plum	2	2026-09-18 05:30:46.017+00	2026-09-18 05:30:25.997+00
9	completed	2026-09-18 05:31:06.023+00	lucky_77	8	2026-09-18 05:31:06.052+00	2026-09-18 05:30:46.023+00
10	completed	2026-09-18 05:31:26.062+00	plum	2	2026-09-18 05:31:26.079+00	2026-09-18 05:31:06.062+00
11	completed	2026-09-18 05:31:46.083+00	watermelon	2	2026-09-18 05:31:46.103+00	2026-09-18 05:31:26.084+00
12	completed	2026-09-18 05:32:06.106+00	watermelon	2	2026-09-18 05:32:06.126+00	2026-09-18 05:31:46.107+00
13	completed	2026-09-18 05:32:26.133+00	lucky_77	8	2026-09-18 05:32:26.151+00	2026-09-18 05:32:06.133+00
14	completed	2026-09-18 05:32:46.156+00	lucky_77	8	2026-09-18 05:32:46.186+00	2026-09-18 05:32:26.157+00
15	completed	2026-09-18 05:33:06.193+00	watermelon	2	2026-09-18 05:33:06.21+00	2026-09-18 05:32:46.194+00
16	completed	2026-09-18 05:33:26.214+00	plum	2	2026-09-18 05:33:26.236+00	2026-09-18 05:33:06.215+00
17	completed	2026-09-18 05:33:46.241+00	plum	2	2026-09-18 05:33:46.26+00	2026-09-18 05:33:26.242+00
18	completed	2026-09-18 05:34:06.265+00	lucky_77	8	2026-09-18 05:34:06.288+00	2026-09-18 05:33:46.266+00
19	completed	2026-09-18 05:34:26.291+00	watermelon	2	2026-09-18 05:34:26.319+00	2026-09-18 05:34:06.292+00
20	completed	2026-09-18 05:34:46.325+00	watermelon	2	2026-09-18 05:34:46.336+00	2026-09-18 05:34:26.326+00
21	completed	2026-09-18 05:35:06.339+00	plum	2	2026-09-18 05:35:06.367+00	2026-09-18 05:34:46.34+00
22	completed	2026-09-18 05:35:26.371+00	plum	2	2026-09-18 05:35:26.387+00	2026-09-18 05:35:06.371+00
23	completed	2026-09-18 05:35:46.391+00	plum	2	2026-09-18 05:35:46.404+00	2026-09-18 05:35:26.392+00
24	completed	2026-09-18 05:36:06.407+00	plum	2	2026-09-18 05:36:06.423+00	2026-09-18 05:35:46.407+00
25	completed	2026-09-18 05:36:26.431+00	watermelon	2	2026-09-18 05:36:26.443+00	2026-09-18 05:36:06.432+00
26	completed	2026-09-18 05:36:46.447+00	watermelon	2	2026-09-18 05:36:46.462+00	2026-09-18 05:36:26.448+00
27	completed	2026-09-18 05:37:06.465+00	plum	2	2026-09-18 05:37:06.488+00	2026-09-18 05:36:46.466+00
28	completed	2026-09-18 05:37:26.491+00	plum	2	2026-09-18 05:37:26.509+00	2026-09-18 05:37:06.491+00
29	completed	2026-09-18 05:37:46.512+00	plum	2	2026-09-18 05:37:46.543+00	2026-09-18 05:37:26.512+00
30	completed	2026-09-18 05:38:06.546+00	watermelon	2	2026-09-18 05:38:06.569+00	2026-09-18 05:37:46.547+00
31	completed	2026-09-18 05:38:26.572+00	lucky_77	8	2026-09-18 05:38:26.596+00	2026-09-18 05:38:06.572+00
32	completed	2026-09-18 05:38:46.6+00	watermelon	2	2026-09-18 05:38:46.625+00	2026-09-18 05:38:26.601+00
33	completed	2026-09-18 05:39:06.629+00	watermelon	2	2026-09-18 05:39:06.654+00	2026-09-18 05:38:46.629+00
34	completed	2026-09-18 05:39:26.659+00	lucky_77	8	2026-09-18 05:39:26.669+00	2026-09-18 05:39:06.66+00
35	completed	2026-09-18 05:39:46.673+00	plum	2	2026-09-18 05:39:46.69+00	2026-09-18 05:39:26.673+00
36	completed	2026-09-18 05:40:06.693+00	lucky_77	8	2026-09-18 05:40:06.714+00	2026-09-18 05:39:46.694+00
37	completed	2026-09-18 05:40:26.717+00	plum	2	2026-09-18 05:40:26.74+00	2026-09-18 05:40:06.718+00
38	completed	2026-09-18 05:40:46.747+00	watermelon	2	2026-09-18 05:40:46.761+00	2026-09-18 05:40:26.748+00
39	completed	2026-09-18 05:41:06.766+00	plum	2	2026-09-18 05:41:06.79+00	2026-09-18 05:40:46.766+00
40	completed	2026-09-18 05:41:26.797+00	watermelon	2	2026-09-18 05:41:26.808+00	2026-09-18 05:41:06.797+00
41	completed	2026-09-18 05:41:46.814+00	plum	2	2026-09-18 05:41:46.823+00	2026-09-18 05:41:26.815+00
42	completed	2026-09-18 05:42:06.825+00	plum	2	2026-09-18 05:42:06.853+00	2026-09-18 05:41:46.826+00
43	completed	2026-09-18 05:42:26.859+00	lucky_77	8	2026-09-18 05:42:26.864+00	2026-09-18 05:42:06.859+00
44	completed	2026-09-18 05:42:46.867+00	plum	2	2026-09-18 05:42:46.882+00	2026-09-18 05:42:26.868+00
45	completed	2026-09-18 05:43:06.885+00	watermelon	2	2026-09-18 05:43:06.902+00	2026-09-18 05:42:46.886+00
46	completed	2026-09-18 05:43:26.905+00	watermelon	2	2026-09-18 05:43:26.926+00	2026-09-18 05:43:06.905+00
47	completed	2026-09-18 05:43:46.929+00	plum	2	2026-09-18 05:43:46.958+00	2026-09-18 05:43:26.93+00
48	completed	2026-09-18 05:44:06.961+00	plum	2	2026-09-18 05:44:06.98+00	2026-09-18 05:43:46.962+00
49	completed	2026-09-18 05:44:26.982+00	plum	2	2026-09-18 05:44:27.009+00	2026-09-18 05:44:06.983+00
50	completed	2026-09-18 05:44:47.011+00	watermelon	2	2026-09-18 05:44:47.043+00	2026-09-18 05:44:27.012+00
51	completed	2026-09-18 05:45:07.045+00	plum	2	2026-09-18 05:45:07.078+00	2026-09-18 05:44:47.046+00
52	completed	2026-09-18 05:45:27.084+00	watermelon	2	2026-09-18 05:45:27.102+00	2026-09-18 05:45:07.085+00
53	completed	2026-09-18 05:45:47.106+00	plum	2	2026-09-18 05:45:47.146+00	2026-09-18 05:45:27.107+00
54	completed	2026-09-18 05:46:07.15+00	plum	2	2026-09-18 05:46:07.165+00	2026-09-18 05:45:47.15+00
55	completed	2026-09-18 05:46:27.169+00	watermelon	2	2026-09-18 05:46:27.184+00	2026-09-18 05:46:07.169+00
56	completed	2026-09-18 05:46:47.186+00	lucky_77	8	2026-09-18 05:46:47.208+00	2026-09-18 05:46:27.187+00
57	completed	2026-09-18 05:47:07.211+00	plum	2	2026-09-18 05:47:07.24+00	2026-09-18 05:46:47.212+00
58	completed	2026-09-18 05:47:27.245+00	watermelon	2	2026-09-18 05:47:27.264+00	2026-09-18 05:47:07.246+00
59	completed	2026-09-18 05:47:47.267+00	watermelon	2	2026-09-18 05:47:47.29+00	2026-09-18 05:47:27.268+00
60	betting	2026-09-18 05:48:07.292+00	\N	\N	\N	2026-09-18 05:47:47.293+00
\.


--
-- Data for Name: media_comments; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.media_comments (id, media_id, user_id, comment, created_at) FROM stdin;
\.


--
-- Data for Name: media_items; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.media_items (id, user_id, kind, media_type, file_url, thumbnail_url, caption, music_url, effect_name, duration, aspect_ratio, is_camera_recorded, likes_count, comments_count, shares_count, views_count, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media_likes; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.media_likes (id, media_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: media_saves; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.media_saves (id, media_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.messages (id, conversation_id, sender_id, message_type, message_text, message_media, gift_id, sticker_id, status, client_uuid, created_at) FROM stdin;
\.


--
-- Data for Name: music_tracks; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.music_tracks (id, title, artist, file_url, is_trending, created_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.refresh_tokens (id, user_id, token, expires_at, created_at) FROM stdin;
8683a663-d19a-4c11-8c00-51e4cb767ad5	1	ebe6e9392afe5847e08dc39a04a6e8156ade4d8d20aa9e23909d20b21bdad74d	2026-10-18 05:29:04.186+00	2026-09-18 05:29:04.187+00
e10cfe03-e9be-4ab7-99ce-819843a349a5	1	04227eb067094b9c191b3b00c555d0a4734ef763d3226f47d27d74dfbe2f2977	2026-10-18 05:29:19.473+00	2026-09-18 05:29:19.475+00
99f13f6f-568e-418b-b85d-bde80818e4d3	1	c2429eef08805f00dcc031c3b827b08ac82f79aafd8c4958ed90942f4b79df9c	2026-10-18 05:30:09.139+00	2026-09-18 05:30:09.14+00
\.


--
-- Data for Name: room_blocks; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.room_blocks (id, room_id, user_id, reason, kind, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: room_members; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.room_members (id, room_id, user_id, role, seat_index, agora_uid, is_active, last_heartbeat_at, joined_at) FROM stdin;
\.


--
-- Data for Name: room_themes; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.room_themes (id, name, image_url, coin_cost, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.rooms (id, display_id, title, owner_id, host_id, co_host_id, agora_channel_name, max_seats, is_live, is_permanent, cover_image_url, description, tags, settings, theme_id, country_code, allowed_country, allowed_gender, min_age, max_age, last_activity_at, host_last_heartbeat_at, ended_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seats; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.seats (id, room_id, seat_index, user_id, is_muted, muted_by_user_id, is_locked, last_heartbeat_at) FROM stdin;
\.


--
-- Data for Name: star_chat_sessions; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.star_chat_sessions (id, conversation_id, payer_id, star_user_id, status, started_at, ended_at, payer_heartbeat_at, price_per_min, commission_percent, coins_charged, gems_credited, end_reason) FROM stdin;
\.


--
-- Data for Name: stickers; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.stickers (id, name, coin_cost, image_url, animation_url, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.user_devices (id, user_id, device_id, platform, fcm_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_followers; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.user_followers (id, follower_id, following_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: user_reports; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.user_reports (id, reporter_id, reported_id, reason, description, created_at) FROM stdin;
\.


--
-- Data for Name: user_unlocked_frames; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.user_unlocked_frames (id, user_id, frame_id, coins_paid, unlocked_at, expires_at) FROM stdin;
\.


--
-- Data for Name: user_unlocked_stickers; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.user_unlocked_stickers (id, user_id, sticker_id, coins_paid, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.users (id, email, phone, password, name, display_name, avatar_url, bio, gender, dob, language, country, role, invite_code, invited_by, email_verified_at, fcm_token, level, exp, xp, coin_balance, wallet_balance, referral_balance, gems, inr_earnings_balance, usd_earnings_balance, private_account, is_private, show_online_status, is_online, last_seen_at, is_suspended, suspended_reason, suspended_until, account_status, deleted_at, is_star_account, star_rank, star_bio_tag, audio_call_rate, video_call_rate, selected_frame_id, last_client_country, created_at, updated_at, selected_entry_bar_id, total_earned_coins, streak_count, last_streak_at) FROM stdin;
1	admin@gmail.com	\N	$2b$10$tOVajJnEUhDbHINRBGe0N.vn.unW7pkP.GU0LUzkFzUzsG7McJd9i	ChatAura Admin	ChatAura Admin	\N	\N	\N	\N	\N	\N	admin	\N	\N	2026-09-18 05:28:58.005+00	\N	1	0	0	0	0	0	0	0	0	f	f	t	f	\N	f	\N	\N	active	\N	f	\N	\N	\N	\N	\N	\N	2026-09-18 05:28:58.007+00	2026-09-18 05:28:58.007+00	\N	0	0	\N
\.


--
-- Data for Name: withdrawal_requests; Type: TABLE DATA; Schema: public; Owner: chataura_user
--

COPY public.withdrawal_requests (id, user_id, amount, currency, withdrawal_source, status, note, created_at, updated_at) FROM stdin;
\.


--
-- Name: agency_affiliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.agency_affiliations_id_seq', 1, false);


--
-- Name: agency_weekly_distributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.agency_weekly_distributions_id_seq', 1, false);


--
-- Name: banners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.banners_id_seq', 1, false);


--
-- Name: blocked_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.blocked_users_id_seq', 1, false);


--
-- Name: bonus_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.bonus_claims_id_seq', 1, false);


--
-- Name: coin_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.coin_packages_id_seq', 1, false);


--
-- Name: coin_purchase_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.coin_purchase_transactions_id_seq', 1, false);


--
-- Name: coin_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.coin_transactions_id_seq', 1, false);


--
-- Name: conversation_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.conversation_participants_id_seq', 1, false);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.conversations_id_seq', 1, false);


--
-- Name: entry_bars_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.entry_bars_id_seq', 1, false);


--
-- Name: faq_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.faq_items_id_seq', 1, false);


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.feedback_id_seq', 1, false);


--
-- Name: frames_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.frames_id_seq', 1, false);


--
-- Name: friend_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.friend_requests_id_seq', 1, false);


--
-- Name: friendships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.friendships_id_seq', 1, false);


--
-- Name: gem_conversions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.gem_conversions_id_seq', 1, false);


--
-- Name: gifts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.gifts_id_seq', 1, false);


--
-- Name: greedy_bets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.greedy_bets_id_seq', 1, false);


--
-- Name: greedy_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.greedy_rounds_id_seq', 60, true);


--
-- Name: levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.levels_id_seq', 1, false);


--
-- Name: lucky77_bets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.lucky77_bets_id_seq', 1, false);


--
-- Name: lucky77_rounds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.lucky77_rounds_id_seq', 60, true);


--
-- Name: media_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.media_comments_id_seq', 1, false);


--
-- Name: media_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.media_items_id_seq', 1, false);


--
-- Name: media_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.media_likes_id_seq', 1, false);


--
-- Name: media_saves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.media_saves_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: music_tracks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.music_tracks_id_seq', 1, false);


--
-- Name: room_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.room_blocks_id_seq', 1, false);


--
-- Name: room_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.room_members_id_seq', 1, false);


--
-- Name: room_themes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.room_themes_id_seq', 1, false);


--
-- Name: seats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.seats_id_seq', 1, false);


--
-- Name: star_chat_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.star_chat_sessions_id_seq', 1, false);


--
-- Name: stickers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.stickers_id_seq', 1, false);


--
-- Name: user_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.user_devices_id_seq', 1, false);


--
-- Name: user_followers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.user_followers_id_seq', 1, false);


--
-- Name: user_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.user_reports_id_seq', 1, false);


--
-- Name: user_unlocked_frames_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.user_unlocked_frames_id_seq', 1, false);


--
-- Name: user_unlocked_stickers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.user_unlocked_stickers_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: withdrawal_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: chataura_user
--

SELECT pg_catalog.setval('public.withdrawal_requests_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: admin_settings admin_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.admin_settings
    ADD CONSTRAINT admin_settings_pkey PRIMARY KEY (id);


--
-- Name: agency_affiliations agency_affiliations_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_affiliations
    ADD CONSTRAINT agency_affiliations_pkey PRIMARY KEY (id);


--
-- Name: agency_weekly_distributions agency_weekly_distributions_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_weekly_distributions
    ADD CONSTRAINT agency_weekly_distributions_pkey PRIMARY KEY (id);


--
-- Name: banners banners_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.banners
    ADD CONSTRAINT banners_pkey PRIMARY KEY (id);


--
-- Name: blocked_users blocked_users_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_pkey PRIMARY KEY (id);


--
-- Name: bonus_claims bonus_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.bonus_claims
    ADD CONSTRAINT bonus_claims_pkey PRIMARY KEY (id);


--
-- Name: coin_packages coin_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_packages
    ADD CONSTRAINT coin_packages_pkey PRIMARY KEY (id);


--
-- Name: coin_purchase_transactions coin_purchase_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_purchase_transactions
    ADD CONSTRAINT coin_purchase_transactions_pkey PRIMARY KEY (id);


--
-- Name: coin_transactions coin_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_transactions
    ADD CONSTRAINT coin_transactions_pkey PRIMARY KEY (id);


--
-- Name: conversation_participants conversation_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: entry_bars entry_bars_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.entry_bars
    ADD CONSTRAINT entry_bars_pkey PRIMARY KEY (id);


--
-- Name: faq_items faq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.faq_items
    ADD CONSTRAINT faq_items_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: frames frames_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.frames
    ADD CONSTRAINT frames_pkey PRIMARY KEY (id);


--
-- Name: friend_requests friend_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_pkey PRIMARY KEY (id);


--
-- Name: friendships friendships_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pkey PRIMARY KEY (id);


--
-- Name: gem_conversions gem_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.gem_conversions
    ADD CONSTRAINT gem_conversions_pkey PRIMARY KEY (id);


--
-- Name: gifts gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- Name: greedy_bets greedy_bets_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.greedy_bets
    ADD CONSTRAINT greedy_bets_pkey PRIMARY KEY (id);


--
-- Name: greedy_rounds greedy_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.greedy_rounds
    ADD CONSTRAINT greedy_rounds_pkey PRIMARY KEY (id);


--
-- Name: levels levels_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.levels
    ADD CONSTRAINT levels_pkey PRIMARY KEY (id);


--
-- Name: lucky77_bets lucky77_bets_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.lucky77_bets
    ADD CONSTRAINT lucky77_bets_pkey PRIMARY KEY (id);


--
-- Name: lucky77_rounds lucky77_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.lucky77_rounds
    ADD CONSTRAINT lucky77_rounds_pkey PRIMARY KEY (id);


--
-- Name: media_comments media_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_comments
    ADD CONSTRAINT media_comments_pkey PRIMARY KEY (id);


--
-- Name: media_items media_items_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_items
    ADD CONSTRAINT media_items_pkey PRIMARY KEY (id);


--
-- Name: media_likes media_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_likes
    ADD CONSTRAINT media_likes_pkey PRIMARY KEY (id);


--
-- Name: media_saves media_saves_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_saves
    ADD CONSTRAINT media_saves_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: music_tracks music_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.music_tracks
    ADD CONSTRAINT music_tracks_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: room_blocks room_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_blocks
    ADD CONSTRAINT room_blocks_pkey PRIMARY KEY (id);


--
-- Name: room_members room_members_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_members
    ADD CONSTRAINT room_members_pkey PRIMARY KEY (id);


--
-- Name: room_themes room_themes_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_themes
    ADD CONSTRAINT room_themes_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: seats seats_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.seats
    ADD CONSTRAINT seats_pkey PRIMARY KEY (id);


--
-- Name: star_chat_sessions star_chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.star_chat_sessions
    ADD CONSTRAINT star_chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: stickers stickers_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.stickers
    ADD CONSTRAINT stickers_pkey PRIMARY KEY (id);


--
-- Name: user_devices user_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_pkey PRIMARY KEY (id);


--
-- Name: user_followers user_followers_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_followers
    ADD CONSTRAINT user_followers_pkey PRIMARY KEY (id);


--
-- Name: user_reports user_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_reports
    ADD CONSTRAINT user_reports_pkey PRIMARY KEY (id);


--
-- Name: user_unlocked_frames user_unlocked_frames_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_frames
    ADD CONSTRAINT user_unlocked_frames_pkey PRIMARY KEY (id);


--
-- Name: user_unlocked_stickers user_unlocked_stickers_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_stickers
    ADD CONSTRAINT user_unlocked_stickers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: withdrawal_requests withdrawal_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.withdrawal_requests
    ADD CONSTRAINT withdrawal_requests_pkey PRIMARY KEY (id);


--
-- Name: agency_affiliations_agency_user_id_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX agency_affiliations_agency_user_id_status_idx ON public.agency_affiliations USING btree (agency_user_id, status);


--
-- Name: agency_affiliations_room_owner_id_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX agency_affiliations_room_owner_id_status_idx ON public.agency_affiliations USING btree (room_owner_id, status);


--
-- Name: agency_weekly_distributions_agency_user_id_period_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX agency_weekly_distributions_agency_user_id_period_id_idx ON public.agency_weekly_distributions USING btree (agency_user_id, period_id);


--
-- Name: agency_weekly_distributions_period_id_agency_user_id_room_owner; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX agency_weekly_distributions_period_id_agency_user_id_room_owner ON public.agency_weekly_distributions USING btree (period_id, agency_user_id, room_owner_id);


--
-- Name: banners_is_active_sort_order_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX banners_is_active_sort_order_idx ON public.banners USING btree (is_active, sort_order);


--
-- Name: blocked_users_blocked_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX blocked_users_blocked_id_idx ON public.blocked_users USING btree (blocked_id);


--
-- Name: blocked_users_blocker_id_blocked_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX blocked_users_blocker_id_blocked_id_key ON public.blocked_users USING btree (blocker_id, blocked_id);


--
-- Name: bonus_claims_user_id_kind_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX bonus_claims_user_id_kind_created_at_idx ON public.bonus_claims USING btree (user_id, kind, created_at);


--
-- Name: coin_packages_is_active_audience_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX coin_packages_is_active_audience_idx ON public.coin_packages USING btree (is_active, audience);


--
-- Name: coin_purchase_transactions_razorpay_order_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX coin_purchase_transactions_razorpay_order_id_key ON public.coin_purchase_transactions USING btree (razorpay_order_id);


--
-- Name: coin_purchase_transactions_razorpay_payment_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX coin_purchase_transactions_razorpay_payment_id_key ON public.coin_purchase_transactions USING btree (razorpay_payment_id);


--
-- Name: coin_purchase_transactions_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX coin_purchase_transactions_status_idx ON public.coin_purchase_transactions USING btree (status);


--
-- Name: coin_purchase_transactions_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX coin_purchase_transactions_user_id_created_at_idx ON public.coin_purchase_transactions USING btree (user_id, created_at);


--
-- Name: coin_transactions_reference_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX coin_transactions_reference_id_idx ON public.coin_transactions USING btree (reference_id);


--
-- Name: coin_transactions_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX coin_transactions_user_id_created_at_idx ON public.coin_transactions USING btree (user_id, created_at);


--
-- Name: conversation_participants_conversation_id_user_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX conversation_participants_conversation_id_user_id_key ON public.conversation_participants USING btree (conversation_id, user_id);


--
-- Name: conversation_participants_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX conversation_participants_user_id_idx ON public.conversation_participants USING btree (user_id);


--
-- Name: frames_is_active_level_required_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX frames_is_active_level_required_idx ON public.frames USING btree (is_active, level_required);


--
-- Name: frames_slug_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX frames_slug_key ON public.frames USING btree (slug);


--
-- Name: friend_requests_receiver_id_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX friend_requests_receiver_id_status_idx ON public.friend_requests USING btree (receiver_id, status);


--
-- Name: friend_requests_sender_id_receiver_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX friend_requests_sender_id_receiver_id_key ON public.friend_requests USING btree (sender_id, receiver_id);


--
-- Name: friendships_friend_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX friendships_friend_id_idx ON public.friendships USING btree (friend_id);


--
-- Name: friendships_user_id_friend_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX friendships_user_id_friend_id_key ON public.friendships USING btree (user_id, friend_id);


--
-- Name: gem_conversions_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX gem_conversions_user_id_created_at_idx ON public.gem_conversions USING btree (user_id, created_at);


--
-- Name: greedy_bets_round_id_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX greedy_bets_round_id_user_id_idx ON public.greedy_bets USING btree (round_id, user_id);


--
-- Name: greedy_rounds_phase_betting_ends_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX greedy_rounds_phase_betting_ends_at_idx ON public.greedy_rounds USING btree (phase, betting_ends_at);


--
-- Name: levels_level_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX levels_level_key ON public.levels USING btree (level);


--
-- Name: lucky77_bets_round_id_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX lucky77_bets_round_id_user_id_idx ON public.lucky77_bets USING btree (round_id, user_id);


--
-- Name: lucky77_rounds_phase_betting_ends_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX lucky77_rounds_phase_betting_ends_at_idx ON public.lucky77_rounds USING btree (phase, betting_ends_at);


--
-- Name: media_comments_media_id_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX media_comments_media_id_created_at_idx ON public.media_comments USING btree (media_id, created_at);


--
-- Name: media_items_kind_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX media_items_kind_created_at_idx ON public.media_items USING btree (kind, created_at);


--
-- Name: media_items_user_id_kind_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX media_items_user_id_kind_idx ON public.media_items USING btree (user_id, kind);


--
-- Name: media_likes_media_id_user_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX media_likes_media_id_user_id_key ON public.media_likes USING btree (media_id, user_id);


--
-- Name: media_saves_media_id_user_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX media_saves_media_id_user_id_key ON public.media_saves USING btree (media_id, user_id);


--
-- Name: messages_conversation_id_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX messages_conversation_id_created_at_idx ON public.messages USING btree (conversation_id, created_at);


--
-- Name: refresh_tokens_token_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX refresh_tokens_token_idx ON public.refresh_tokens USING btree (token);


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX refresh_tokens_user_id_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: room_blocks_room_id_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX room_blocks_room_id_user_id_idx ON public.room_blocks USING btree (room_id, user_id);


--
-- Name: room_members_room_id_is_active_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX room_members_room_id_is_active_idx ON public.room_members USING btree (room_id, is_active);


--
-- Name: room_members_room_id_user_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX room_members_room_id_user_id_key ON public.room_members USING btree (room_id, user_id);


--
-- Name: rooms_display_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX rooms_display_id_key ON public.rooms USING btree (display_id);


--
-- Name: rooms_is_live_last_activity_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX rooms_is_live_last_activity_at_idx ON public.rooms USING btree (is_live, last_activity_at);


--
-- Name: rooms_owner_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX rooms_owner_id_idx ON public.rooms USING btree (owner_id);


--
-- Name: seats_room_id_seat_index_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX seats_room_id_seat_index_key ON public.seats USING btree (room_id, seat_index);


--
-- Name: seats_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX seats_user_id_idx ON public.seats USING btree (user_id);


--
-- Name: star_chat_sessions_conversation_id_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX star_chat_sessions_conversation_id_status_idx ON public.star_chat_sessions USING btree (conversation_id, status);


--
-- Name: star_chat_sessions_payer_id_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX star_chat_sessions_payer_id_status_idx ON public.star_chat_sessions USING btree (payer_id, status);


--
-- Name: user_devices_user_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX user_devices_user_id_idx ON public.user_devices USING btree (user_id);


--
-- Name: user_followers_follower_id_following_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX user_followers_follower_id_following_id_key ON public.user_followers USING btree (follower_id, following_id);


--
-- Name: user_followers_following_id_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX user_followers_following_id_status_idx ON public.user_followers USING btree (following_id, status);


--
-- Name: user_reports_reported_id_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX user_reports_reported_id_idx ON public.user_reports USING btree (reported_id);


--
-- Name: user_unlocked_frames_user_id_frame_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX user_unlocked_frames_user_id_frame_id_key ON public.user_unlocked_frames USING btree (user_id, frame_id);


--
-- Name: user_unlocked_stickers_user_id_sticker_id_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX user_unlocked_stickers_user_id_sticker_id_key ON public.user_unlocked_stickers USING btree (user_id, sticker_id);


--
-- Name: users_account_status_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX users_account_status_idx ON public.users USING btree (account_status);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_invite_code_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX users_invite_code_key ON public.users USING btree (invite_code);


--
-- Name: users_is_star_account_star_rank_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX users_is_star_account_star_rank_idx ON public.users USING btree (is_star_account, star_rank);


--
-- Name: users_phone_key; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE UNIQUE INDEX users_phone_key ON public.users USING btree (phone);


--
-- Name: withdrawal_requests_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: chataura_user
--

CREATE INDEX withdrawal_requests_user_id_created_at_idx ON public.withdrawal_requests USING btree (user_id, created_at);


--
-- Name: agency_affiliations agency_affiliations_agency_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_affiliations
    ADD CONSTRAINT agency_affiliations_agency_user_id_fkey FOREIGN KEY (agency_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agency_affiliations agency_affiliations_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_affiliations
    ADD CONSTRAINT agency_affiliations_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: agency_affiliations agency_affiliations_room_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_affiliations
    ADD CONSTRAINT agency_affiliations_room_owner_id_fkey FOREIGN KEY (room_owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agency_weekly_distributions agency_weekly_distributions_room_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.agency_weekly_distributions
    ADD CONSTRAINT agency_weekly_distributions_room_owner_id_fkey FOREIGN KEY (room_owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: blocked_users blocked_users_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: blocked_users blocked_users_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bonus_claims bonus_claims_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.bonus_claims
    ADD CONSTRAINT bonus_claims_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coin_purchase_transactions coin_purchase_transactions_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_purchase_transactions
    ADD CONSTRAINT coin_purchase_transactions_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.coin_packages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: coin_purchase_transactions coin_purchase_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_purchase_transactions
    ADD CONSTRAINT coin_purchase_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coin_transactions coin_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.coin_transactions
    ADD CONSTRAINT coin_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_participants conversation_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.conversation_participants
    ADD CONSTRAINT conversation_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: feedback feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: friend_requests friend_requests_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friend_requests friend_requests_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friend_requests
    ADD CONSTRAINT friend_requests_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friendships friendships_friend_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_friend_id_fkey FOREIGN KEY (friend_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: friendships friendships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gem_conversions gem_conversions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.gem_conversions
    ADD CONSTRAINT gem_conversions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: greedy_bets greedy_bets_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.greedy_bets
    ADD CONSTRAINT greedy_bets_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.greedy_rounds(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: greedy_bets greedy_bets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.greedy_bets
    ADD CONSTRAINT greedy_bets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lucky77_bets lucky77_bets_round_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.lucky77_bets
    ADD CONSTRAINT lucky77_bets_round_id_fkey FOREIGN KEY (round_id) REFERENCES public.lucky77_rounds(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lucky77_bets lucky77_bets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.lucky77_bets
    ADD CONSTRAINT lucky77_bets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_comments media_comments_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_comments
    ADD CONSTRAINT media_comments_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_comments media_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_comments
    ADD CONSTRAINT media_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_items media_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_items
    ADD CONSTRAINT media_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_likes media_likes_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_likes
    ADD CONSTRAINT media_likes_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_likes media_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_likes
    ADD CONSTRAINT media_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_saves media_saves_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_saves
    ADD CONSTRAINT media_saves_media_id_fkey FOREIGN KEY (media_id) REFERENCES public.media_items(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media_saves media_saves_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.media_saves
    ADD CONSTRAINT media_saves_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: room_blocks room_blocks_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_blocks
    ADD CONSTRAINT room_blocks_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: room_blocks room_blocks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_blocks
    ADD CONSTRAINT room_blocks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: room_members room_members_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_members
    ADD CONSTRAINT room_members_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: room_members room_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.room_members
    ADD CONSTRAINT room_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rooms rooms_co_host_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_co_host_id_fkey FOREIGN KEY (co_host_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rooms rooms_host_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_host_id_fkey FOREIGN KEY (host_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rooms rooms_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rooms rooms_theme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_theme_id_fkey FOREIGN KEY (theme_id) REFERENCES public.room_themes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: seats seats_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.seats
    ADD CONSTRAINT seats_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seats seats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.seats
    ADD CONSTRAINT seats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: star_chat_sessions star_chat_sessions_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.star_chat_sessions
    ADD CONSTRAINT star_chat_sessions_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: star_chat_sessions star_chat_sessions_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.star_chat_sessions
    ADD CONSTRAINT star_chat_sessions_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: star_chat_sessions star_chat_sessions_star_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.star_chat_sessions
    ADD CONSTRAINT star_chat_sessions_star_user_id_fkey FOREIGN KEY (star_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_devices user_devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_devices
    ADD CONSTRAINT user_devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_followers user_followers_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_followers
    ADD CONSTRAINT user_followers_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_followers user_followers_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_followers
    ADD CONSTRAINT user_followers_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_reports user_reports_reported_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_reports
    ADD CONSTRAINT user_reports_reported_id_fkey FOREIGN KEY (reported_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_reports user_reports_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_reports
    ADD CONSTRAINT user_reports_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_unlocked_frames user_unlocked_frames_frame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_frames
    ADD CONSTRAINT user_unlocked_frames_frame_id_fkey FOREIGN KEY (frame_id) REFERENCES public.frames(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_unlocked_frames user_unlocked_frames_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_frames
    ADD CONSTRAINT user_unlocked_frames_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_unlocked_stickers user_unlocked_stickers_sticker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_stickers
    ADD CONSTRAINT user_unlocked_stickers_sticker_id_fkey FOREIGN KEY (sticker_id) REFERENCES public.stickers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_unlocked_stickers user_unlocked_stickers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.user_unlocked_stickers
    ADD CONSTRAINT user_unlocked_stickers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_selected_entry_bar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_selected_entry_bar_id_fkey FOREIGN KEY (selected_entry_bar_id) REFERENCES public.entry_bars(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_selected_frame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_selected_frame_id_fkey FOREIGN KEY (selected_frame_id) REFERENCES public.frames(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: withdrawal_requests withdrawal_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: chataura_user
--

ALTER TABLE ONLY public.withdrawal_requests
    ADD CONSTRAINT withdrawal_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict oJuLe0hBXFutax0qOBwtHL4682x0mIDSHuIrDfDz0e9xOPexlSq3Y6FftVEwmzn

